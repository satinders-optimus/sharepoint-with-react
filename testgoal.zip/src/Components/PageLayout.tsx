import React from "react";
import Navbar from "react-bootstrap/Navbar";
import { useIsAuthenticated } from "@azure/msal-react";
import { SignInButton } from "./SignInButton";
import HomePage from "../HomePage";

/**
 * Renders the navbar component with a sign-in button if a user is not authenticated
 */
export const PageLayout = (props: any) => {
  const isAuthenticated = useIsAuthenticated();
  debugger;
  return (
    <>
      <Navbar bg="primary" variant="light">
        {isAuthenticated ? (
          <HomePage />
        ) : (
          // props.children
          <SignInButton />
        )}
      </Navbar>
      {/* <h5>
        <center>
          Welcome to the Microsoft Authentication Library For React Tutorial
        </center>
      </h5>
      <br />
      <br /> */}
      {/* {props.children} */}
    </>
  );
};
